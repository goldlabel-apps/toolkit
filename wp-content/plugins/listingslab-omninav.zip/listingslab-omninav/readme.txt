=== Listingslab @Omninav ===

Contributors:      listingslab
Tags:              gdpr, MUI,
Requires at least: 5.5
Tested up to:      5.6
License:           GPLv2 or later
License URI:       http://www.gnu.org/licenses/gpl-2.0.html
Requires PHP:      5.6

== Description ==


