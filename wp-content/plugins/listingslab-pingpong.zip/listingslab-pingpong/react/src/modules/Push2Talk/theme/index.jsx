import Icon from './Icon'
import { theme } from './theme'

export {
	Icon,
	theme,
}
