import React from 'react'
// import clsx from 'clsx'
import { useSelector } from 'react-redux'
import { makeFingerprint } from './redux/actions'
import {    
	// makeStyles,
	// Card,
	// CardHeader,
	// Typography,
	// Grid,
} from '@material-ui/core/'
// import { Icon } from './theme'
// import {
// 	Device,
// 	Location,
// } from './components'

// const useStyles = makeStyles(theme => ({
// 	push2Talk: {
// 		// width: '100%',
// 		margin: theme.spacing(),
// 	},
// }))

export default function Push2Talk() {
	
	// const classes = useStyles()
	const p2TSlice = useSelector(state => state.p2T)
	// console.log ('p2TSlice', p2TSlice)
    React.useEffect(() => {
    	const {
    		block,
    		ting,
    	} = p2TSlice
    	const {
    		fingerprint,
    	} = ting
    	// console.log (block, fingerprint)
    	if ( !block && !fingerprint) makeFingerprint()
	}, [p2TSlice])

	return null
}

/*
<div className={ clsx( classes.push2Talk ) }>
					<Card>
						<CardHeader 
							disableTypography
							avatar={ <Icon icon={`push2Talk`} color={ `error` } /> }
							title={	<Typography variant={`h6`} color={ `error` }>
										Push2Talk
									</Typography>} />
							<Grid container>
								<Grid item >
									<Device />
								</Grid>
								<Grid item >
									<Location />
								</Grid>
							</Grid>
					</Card>
				</div>
*/
