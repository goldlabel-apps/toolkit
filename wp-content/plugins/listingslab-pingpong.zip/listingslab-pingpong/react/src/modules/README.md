
# React Modules


Modules are a new concept we are playing with. They're along the lines of components, but bigger. They're more like whole standalone apps which can be inclued into other apps

- Push2Talk
	- GDPR
	- Messaging
	- Analytics

- Cannastore
	- Affiliate Marketing
	- Algolis Search as a Service
	