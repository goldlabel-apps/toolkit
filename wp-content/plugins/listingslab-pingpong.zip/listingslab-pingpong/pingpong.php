<?php

/**
 * @link              https://listingslab.com?s=pingpong
 * @package           listingslab
 *
 * @wordpress-plugin
 * Version:           10.0.1
 * Plugin Name:       @PingPong
 * Description:       Listingslab ToolKit Plugin &nbsp;<a href="/wp-admin/admin.php?page=toolkitadmin">Settings</a>
 * Plugin URI:        https://listingslab.com?s=pingpong
 * Author:            listingslab
 * Author URI:        https://listingslab.com?s=author
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       listingslab
 * Domain Path:       /languages
 */

