=== Listingslab @_Toolkit Manager ===

Contributors:      listingslab
Tags:              wp-admin
Requires at least: 5.5
Tested up to:      5.6
License:           GPLv2 or later
License URI:       http://www.gnu.org/licenses/gpl-2.0.html
Requires PHP:      5.6

== Description ==

> A suite of WordPress Plugins which open up a world of good stuff to any tired old WordPress site. [Documentation](https://github.com/listingslab-software/toolkit/tree/master/docs) for WordPress Administrators, Developers and DevOps